<?php
session_start();

// --- 模拟数据库初始化 ---
if (!isset($_SESSION['accounts'])) {
    $_SESSION['accounts'] = [
        ['id' => 1024, 'username' => '星云掌门', 'password' => '123', 'points' => 999999, 'vip' => 12, 'isGM' => true, 'status' => '正常', 'lastLogin' => '2024-05-24'],
        ['id' => 1025, 'username' => '独孤求败', 'password' => '123', 'points' => 1500, 'vip' => 5, 'isGM' => false, 'status' => '正常', 'lastLogin' => '2024-05-23'],
        ['id' => 1026, 'username' => '邪教魔头', 'password' => '123', 'points' => 0, 'vip' => 0, 'isGM' => false, 'status' => '封禁', 'lastLogin' => '2024-01-10'],
    ];
}

if (!isset($_SESSION['characters'])) {
    $_SESSION['characters'] = [
        ['id' => 1, 'userId' => 1024, 'name' => '苍穹剑仙', 'level' => 120, 'roles' => '剑圣', 'pvp' => 9999, 'inventory' => ['轩辕剑', '九转金丹'], 'warehouse' => ['玄铁石'], 'skills' => ['万剑归宗'], 'titles' => ['盟主']],
        ['id' => 2, 'userId' => 1025, 'name' => '求败一生', 'level' => 115, 'roles' => '邪皇', 'pvp' => 8888, 'inventory' => ['重剑'], 'warehouse' => [], 'skills' => ['独孤九剑'], 'titles' => ['剑魔']],
    ];
}

if (!isset($_SESSION['announcements'])) {
    $_SESSION['announcements'] = [
        ['id' => 1, 'content' => '百晓生传讯：服务器灵气充沛，诸位大侠可安心历练。', 'type' => '即时', 'time' => '', 'active' => true],
        ['id' => 2, 'content' => '今夜亥时，华山巅峰将举行宗门大比。', 'type' => '定时', 'time' => '21:00', 'active' => true],
    ];
}

if (!isset($_SESSION['db_config'])) {
    $_SESSION['db_config'] = [
        'host' => '127.0.0.1', 'port' => '3306', 'name' => 'wulin_db', 'user' => 'root', 'pass' => '',
        'gdeliveryd' => '29100', 'ganedbd' => '29400', 'uniquenamed' => '29401'
    ];
}

// --- 处理 POST 请求 ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add_account') {
        $_SESSION['accounts'][] = [
            'id' => rand(1000, 9999), 'username' => $_POST['username'], 'password' => $_POST['password'] ?: '123',
            'points' => (int)$_POST['points'], 'vip' => (int)$_POST['vip'], 'isGM' => isset($_POST['isGM']), 'status' => '正常', 'lastLogin' => date('Y-m-d')
        ];
    }
    // 其他处理逻辑类似...
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

$accounts_json = json_encode($_SESSION['accounts']);
$characters_json = json_encode($_SESSION['characters']);
$announcements_json = json_encode($_SESSION['announcements']);
$db_config = $_SESSION['db_config'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>星云阁·PHP管理中枢</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- 关键修复：导入映射 -->
    <script type="importmap">
    {
      "imports": {
        "@google/genai": "https://esm.sh/@google/genai@1.3.0"
      }
    }
    </script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+SC:wght@400;900&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Noto Serif SC', serif; background: #0c0c0e; color: #d4af37; }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #d4af3744; border-radius: 10px; }
    </style>
</head>
<body x-data="nebulaApp()" x-init="initChart()" class="overflow-hidden">
    <div class="flex h-screen w-screen" x-cloak>
        <!-- 侧边栏 -->
        <aside class="w-64 border-r border-[#d4af3711] bg-[#0c0c0e] p-6 flex flex-col">
            <div class="flex items-center gap-3 mb-12">
                <div class="p-2 bg-[#d4af37] rounded text-black">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                </div>
                <h1 class="text-xl font-black tracking-tighter">星云阁<span class="opacity-50 text-sm ml-1">GM</span></h1>
            </div>
            <nav class="flex-1 space-y-2">
                <button @click="tab = 'dash'" :class="tab==='dash'?'bg-[#d4af3711] text-[#d4af37]':'text-white/40'" class="w-full text-left px-4 py-3 rounded text-sm font-bold transition-all">乾坤概览</button>
                <button @click="tab = 'list'" :class="tab==='list'?'bg-[#d4af3711] text-[#d4af37]':'text-white/40'" class="w-full text-left px-4 py-3 rounded text-sm font-bold transition-all">弟子名册</button>
            </nav>
        </aside>

        <!-- 主界面 -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <header class="h-20 border-b border-[#d4af3711] flex items-center justify-between px-10 bg-[#0c0c0e]">
                <div class="flex items-center gap-4">
                    <span class="text-xs font-bold px-3 py-1 bg-[#d4af3711] border border-[#d4af3733] rounded-full animate-pulse">
                        江湖密讯: <span x-text="announcements[annIndex].content"></span>
                    </span>
                </div>
                <button @click="showConfig = true" class="text-white/40 hover:text-[#d4af37] transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                </button>
            </header>

            <div class="flex-1 overflow-y-auto p-10 custom-scrollbar">
                <div x-show="tab === 'dash'" class="space-y-10">
                    <div class="grid grid-cols-3 gap-6">
                        <div class="bg-white/5 p-6 rounded border border-white/5">
                            <p class="text-[10px] uppercase font-bold opacity-40 mb-2">名册总数</p>
                            <h2 class="text-3xl font-black text-white"><?php echo count($_SESSION['accounts']); ?></h2>
                        </div>
                        <div class="bg-white/5 p-6 rounded border border-white/5">
                            <p class="text-[10px] uppercase font-bold opacity-40 mb-2">灵气盈余</p>
                            <h2 class="text-3xl font-black text-white">1.2M</h2>
                        </div>
                        <div class="bg-white/5 p-6 rounded border border-white/5">
                            <p class="text-[10px] uppercase font-bold opacity-40 mb-2">网关延迟</p>
                            <h2 class="text-3xl font-black text-emerald-500">12ms</h2>
                        </div>
                    </div>
                    <div class="bg-white/5 p-8 rounded border border-white/5">
                        <div id="mainChart"></div>
                    </div>
                </div>

                <div x-show="tab === 'list'" class="bg-white/5 rounded border border-white/5 overflow-hidden">
                    <table class="w-full text-left">
                        <thead class="bg-white/5 text-[10px] font-bold uppercase text-white/30">
                            <tr>
                                <th class="px-6 py-4">弟子名号</th>
                                <th class="px-6 py-4">元宝</th>
                                <th class="px-6 py-4">状态</th>
                                <th class="px-6 py-4 text-right">操作</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-white/5">
                            <template x-for="acc in accounts">
                                <tr class="hover:bg-white/5 transition-colors">
                                    <td class="px-6 py-4">
                                        <div class="text-white font-bold" x-text="acc.username"></div>
                                        <div class="text-[9px] opacity-30" x-text="'ID: '+acc.id"></div>
                                    </td>
                                    <td class="px-6 py-4 font-black text-[#d4af37]" x-text="acc.points"></td>
                                    <td class="px-6 py-4">
                                        <span x-text="acc.status" :class="acc.status==='正常'?'text-emerald-500':'text-rose-500'" class="text-[10px] font-bold"></span>
                                    </td>
                                    <td class="px-6 py-4 text-right">
                                        <button class="text-white/40 hover:text-white px-2">管理</button>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- 配置弹窗 -->
    <div x-show="showConfig" class="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-6">
        <div class="bg-[#121214] border border-[#d4af3733] w-full max-w-md p-10 rounded shadow-2xl">
            <h3 class="text-xl font-bold mb-6">网关配置 (Database: <?php echo $db_config['name']; ?>)</h3>
            <div class="space-y-4 text-sm">
                <div class="flex justify-between border-b border-white/5 py-2"><span>Host:</span><span class="text-white font-mono"><?php echo $db_config['host']; ?></span></div>
                <div class="flex justify-between border-b border-white/5 py-2"><span>Port:</span><span class="text-white font-mono"><?php echo $db_config['port']; ?></span></div>
                <div class="flex justify-between border-b border-white/5 py-2"><span>DB Name:</span><span class="text-white font-mono"><?php echo $db_config['name']; ?></span></div>
            </div>
            <button @click="showConfig = false" class="w-full mt-8 py-3 bg-[#d4af37] text-black font-bold rounded">返回</button>
        </div>
    </div>

    <script type="module">
        import { GoogleGenAI } from "@google/genai";

        window.nebulaApp = () => ({
            tab: 'dash',
            annIndex: 0,
            showConfig: false,
            accounts: <?php echo $accounts_json; ?>,
            announcements: <?php echo $announcements_json; ?>,
            
            init() {
                setInterval(() => {
                    this.annIndex = (this.annIndex + 1) % this.announcements.length;
                }, 4000);
            },

            initChart() {
                this.$nextTick(() => {
                    new ApexCharts(document.querySelector("#mainChart"), {
                        series: [{ name: '灵压', data: [31, 40, 28, 51, 42, 109, 100] }],
                        chart: { height: 350, type: 'area', toolbar: {show:false}, background: 'transparent' },
                        colors: ['#d4af37'],
                        dataLabels: { enabled: false },
                        stroke: { curve: 'smooth' },
                        xaxis: { categories: ["子", "丑", "寅", "卯", "辰", "巳", "午"], labels: {style:{colors:'#d4af3744'}} },
                        theme: { mode: 'dark' },
                        grid: { borderColor: '#ffffff11' }
                    }).render();
                });
            }
        });
    </script>
</body>
</html>
