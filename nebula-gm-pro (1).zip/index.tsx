
import React, { useState, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  Users, ShieldCheck, Gamepad2, Database, Activity, Search, Settings, 
  MessageSquare, TrendingUp, Cpu, LogOut, ChevronRight, Package, Zap, 
  Filter, BarChart3, Edit3, Trash2, Key, Star, Crown, DollarSign, 
  Megaphone, Clock, Plus, Save, X, RefreshCw, UserPlus, BookOpen, Trophy, Users2, Briefcase,
  Flame, Sword, Scroll, Shield, Heart, Map, Sparkles, AlertTriangle, Link, Globe, Server,
  ChevronLeft, Eye, CheckSquare, Square, Ban, CheckCircle2, ShieldAlert
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';
import { GoogleGenAI } from "@google/genai";

// --- 武侠风格辅助组件 ---

const CornerDecor = ({ className = "" }) => (
  <svg className={`absolute w-8 h-8 ${className}`} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0 0H32M0 0V32M4 4H28M4 4V28" stroke="#d4af37" strokeWidth="0.5" strokeOpacity="0.6"/>
    <rect x="0" y="0" width="2" height="2" fill="#d4af37" />
  </svg>
);

const CloudPattern = () => (
  <div className="absolute inset-0 pointer-events-none opacity-[0.03] overflow-hidden">
    <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
      <pattern id="clouds" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
        <path d="M25 50 Q 35 30 50 50 Q 65 70 75 50" fill="none" stroke="#d4af37" strokeWidth="1" />
      </pattern>
      <rect width="100%" height="100%" fill="url(#clouds)" />
    </svg>
  </div>
);

// --- 类型定义 ---
type JobType = '剑圣' | '邪皇' | '医仙' | '神算' | '魔尊' | '天师';
const JOBS: JobType[] = ['剑圣', '邪皇', '医仙', '神算', '魔尊', '天师'];

interface Character {
  id: number;
  userId: number;
  name: string;
  level: number;
  roles: JobType;
  pvp: number;
  inventory: string[];
  warehouse: string[];
  skills: string[];
  titles: string[];
  friends: string[];
}

interface UserAccount {
  id: number;
  username: string;
  password?: string;
  points: number;
  vip: number;
  isGM: boolean;
  status: '正常' | '封禁';
  lastLogin: string;
}

interface Announcement {
  id: number;
  content: string;
  type: '即时' | '定时';
  time?: string;
  active: boolean;
}

const MOCK_ACCOUNTS: UserAccount[] = [
  { id: 1024, username: '星云掌门', password: '123', points: 999999, vip: 12, isGM: true, status: '正常', lastLogin: '2024-05-24' },
  { id: 1025, username: '独孤求败', password: '123', points: 1500, vip: 5, isGM: false, status: '正常', lastLogin: '2024-05-23' },
  { id: 1026, username: '邪教魔头', password: '123', points: 0, vip: 0, isGM: false, status: '封禁', lastLogin: '2024-01-10' },
];

const MOCK_CHARACTERS: Character[] = [
  { 
    id: 1, userId: 1024, name: '苍穹剑仙', level: 120, roles: '剑圣', pvp: 9999,
    inventory: ['轩辕剑', '九转金丹', '回城卷轴', '红宝石 x10'],
    warehouse: ['玄铁石', '龙之逆鳞', '远古卷轴'],
    skills: ['万剑归宗', '天外飞仙'],
    titles: ['武林盟主', '剑道巅峰'],
    friends: ['月下独酌']
  },
  { 
    id: 2, userId: 1025, name: '求败一生', level: 115, roles: '邪皇', pvp: 8888,
    inventory: ['玄铁重剑'],
    warehouse: ['无名残页'],
    skills: ['独孤九剑'],
    titles: ['剑魔'],
    friends: []
  },
];

const GROWTH_DATA = [
  { time: '子时', users: 120 }, { time: '寅时', users: 80 },
  { time: '辰时', users: 450 }, { time: '午时', users: 890 },
  { time: '申时', users: 1200 }, { time: '戌时', users: 2100 },
  { time: '亥时', users: 1500 },
];

const TraditionalBadge = ({ children, color = "gold" }: any) => {
  const styles: any = {
    gold: "bg-[#d4af37]/10 text-[#d4af37] border-[#d4af37]/30 shadow-[0_0_10px_rgba(212,175,55,0.1)]",
    jade: "bg-[#00a86b]/10 text-[#00a86b] border-[#00a86b]/30",
    ink: "bg-slate-800 text-slate-400 border-slate-700",
    vermillion: "bg-[#e34234]/10 text-[#e34234] border-[#e34234]/30",
    purple: "bg-purple-500/10 text-purple-400 border-purple-500/30",
    emerald: "bg-[#2ecc71]/10 text-[#2ecc71] border-[#2ecc71]/30",
  };
  return (
    <span className={`px-2 py-0.5 text-[10px] font-bold tracking-widest rounded-sm border ${styles[color]} backdrop-blur-sm flex items-center gap-1.5`}>
      {children}
    </span>
  );
};

const SidebarItem = ({ icon: Icon, label, active, onClick }: any) => {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-4 py-3.5 rounded transition-all duration-300 group relative ${
        active 
          ? 'bg-[#d4af37]/10 text-[#d4af37] border-l-2 border-[#d4af37]' 
          : 'text-[#d4af37]/40 hover:bg-[#d4af37]/5 hover:text-[#d4af37]/70'
      }`}
    >
      <Icon size={18} className={active ? 'text-[#d4af37]' : 'text-inherit'} />
      <span className="text-xs font-black tracking-[0.2em]">{label}</span>
      {active && (
        <div className="absolute right-4 w-1 h-3 bg-[#d4af37] rounded-full shadow-[0_0_8px_#d4af37]" />
      )}
    </button>
  );
};

const Modal = ({ title, isOpen, onClose, children }: any) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
      <div className="bg-[#121214] border border-[#d4af37]/30 w-full max-w-2xl rounded-lg shadow-[0_0_50px_rgba(212,175,55,0.05)] overflow-hidden animate-in fade-in zoom-in duration-300 relative">
        <CornerDecor className="top-0 left-0" />
        <CornerDecor className="top-0 right-0 rotate-90" />
        <CornerDecor className="bottom-0 left-0 -rotate-90" />
        <CornerDecor className="bottom-0 right-0 rotate-180" />
        <div className="flex justify-between items-center p-6 border-b border-[#d4af37]/10 relative">
          <h3 className="text-xl font-black text-[#d4af37] flex items-center gap-3 tracking-widest uppercase">
            <Scroll size={24} className="opacity-70" /> {title}
          </h3>
          <button onClick={onClose} className="text-[#d4af37]/50 hover:text-[#d4af37] transition-all"><X size={24}/></button>
        </div>
        <div className="p-8 max-h-[85vh] overflow-y-auto custom-scrollbar relative z-10">{children}</div>
      </div>
    </div>
  );
};

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionStage, setConnectionStage] = useState(0);
  
  const [dbConfig, setDbConfig] = useState({ 
    host: '127.0.0.1', 
    port: '3306', 
    name: 'wulin_db', 
    user: 'root',
    pass: '',
    gdeliveryd: '29100',
    ganedbd: '29400',
    uniquenamed: '29401'
  });

  const [activeTab, setActiveTab] = useState('dashboard');
  const [accounts, setAccounts] = useState<UserAccount[]>(MOCK_ACCOUNTS);
  const [characters, setCharacters] = useState<Character[]>(MOCK_CHARACTERS);
  const [announcements, setAnnouncements] = useState<Announcement[]>([
    { id: 1, content: "百晓生传讯：服务器灵气充沛，诸位大侠可安心历练。", type: '即时', active: true },
    { id: 2, content: "今夜亥时，华山巅峰将举行宗门大比，请诸位准备。", type: '定时', time: '21:00', active: true },
  ]);
  
  const [activeAnnIndex, setActiveAnnIndex] = useState(0);
  const [chat, setChat] = useState<{role: string, content: string}[]>([]);
  const [input, setInput] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [selectedAccountIds, setSelectedAccountIds] = useState<number[]>([]);
  
  const [editModal, setEditModal] = useState<{
    type: 'password' | 'recharge' | 'add_account' | 'add_announcement' | 'delete_account' | 'db_settings' | 'char_details' | 'edit_inventory' | 'batch_recharge' | 'batch_ban', 
    target?: any
  } | null>(null);

  const [editingCharId, setEditingCharId] = useState<number | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveAnnIndex(prev => (prev + 1) % (announcements.length || 1));
    }, 5000);
    return () => clearInterval(timer);
  }, [announcements]);

  const handleConnect = (e: React.FormEvent) => {
    e.preventDefault();
    setIsConnecting(true);
    setConnectionStage(1);

    setTimeout(() => {
      setConnectionStage(2); 
      setTimeout(() => {
        setConnectionStage(3); 
        setTimeout(() => {
          setIsLoggedIn(true);
          setIsConnecting(false);
          setConnectionStage(0);
        }, 800);
      }, 800);
    }, 800);
  };

  const handleAddAccount = (formData: any) => {
    const newAcc: UserAccount = {
      id: Math.floor(Math.random() * 9000) + 1000,
      username: formData.username,
      password: formData.password || '123',
      points: Number(formData.points) || 0,
      vip: Number(formData.vip) || 0,
      isGM: !!formData.isGM,
      status: '正常',
      lastLogin: new Date().toISOString().split('T')[0]
    };
    setAccounts([newAcc, ...accounts]);
    setEditModal(null);
  };

  const handleUpdateAccount = (id: number, updates: Partial<UserAccount>) => {
    setAccounts(accounts.map(acc => acc.id === id ? { ...acc, ...updates } : acc));
    setEditModal(null);
  };

  const handleDeleteAccount = (id: number) => {
    setAccounts(accounts.filter(acc => acc.id !== id));
    setCharacters(characters.filter(char => char.userId !== id));
    setSelectedAccountIds(prev => prev.filter(pId => pId !== id));
    setEditModal(null);
  };

  const handleBatchDelete = () => {
    if (confirm(`确定要批量驱逐这 ${selectedAccountIds.length} 位弟子吗？`)) {
      setAccounts(accounts.filter(acc => !selectedAccountIds.includes(acc.id)));
      setCharacters(characters.filter(char => !selectedAccountIds.includes(char.userId)));
      setSelectedAccountIds([]);
    }
  };

  const handleBatchRecharge = (amount: number) => {
    setAccounts(accounts.map(acc => selectedAccountIds.includes(acc.id) ? { ...acc, points: acc.points + amount } : acc));
    setSelectedAccountIds([]);
    setEditModal(null);
  };

  const handleBatchBan = (status: '正常' | '封禁') => {
    setAccounts(accounts.map(acc => selectedAccountIds.includes(acc.id) ? { ...acc, status } : acc));
    setSelectedAccountIds([]);
    setEditModal(null);
  };

  const handleUpdatePassword = (id: number, newPass: string) => {
    setAccounts(accounts.map(acc => acc.id === id ? { ...acc, password: newPass } : acc));
    alert("通关密语重设成功。");
    setEditModal(null);
  };

  const handleDeleteCharacter = (id: number) => {
    if (confirm("确定要销毁该豪杰的一切江湖印记吗？")) {
      setCharacters(characters.filter(c => c.id !== id));
    }
  };

  const handleUpdateCharacter = (id: number, updates: Partial<Character>) => {
    setCharacters(characters.map(c => c.id === id ? { ...c, ...updates } : c));
    setEditingCharId(null);
  };

  const handleAddAnnouncement = (formData: any) => {
    const newAnn: Announcement = {
      id: announcements.length + 1,
      content: formData.content,
      type: formData.type as '即时' | '定时',
      time: formData.time,
      active: true
    };
    setAnnouncements([newAnn, ...announcements]);
    setEditModal(null);
  };

  const handleDeleteAnnouncement = (id: number) => {
    setAnnouncements(announcements.filter(ann => ann.id !== id));
  };

  const askAi = async () => {
    if (!input) return;
    const userMsg = input;
    setInput('');
    setChat(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsAiLoading(true);

    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) {
        throw new Error("Missing API Key");
      }
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `你是一个深谙服务器运维的武林百晓生。IP: ${dbConfig.host}, 数据库: ${dbConfig.name}, Gdeliveryd: ${dbConfig.gdeliveryd}。问题：${userMsg}`,
        config: { systemInstruction: "使用专业的武侠运维口吻回复。" }
      });
      setChat(prev => [...prev, { role: 'assistant', content: response.text || '老朽分析完毕。' }]);
    } catch (err) {
      setChat(prev => [...prev, { role: 'assistant', content: '传音链路受阻，请确保秘钥配置正确。' }]);
    } finally {
      setIsAiLoading(false);
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#0c0c0e] flex items-center justify-center p-6 relative overflow-hidden">
        <CloudPattern />
        
        {isConnecting && (
          <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0c0c0e]/95 backdrop-blur-md">
            <div className="relative w-48 h-48 mb-8">
               <div className="absolute inset-0 border-4 border-[#d4af37]/10 rounded-full" />
               <div className="absolute inset-0 border-4 border-[#d4af37] rounded-full border-t-transparent animate-spin" />
               <div className="absolute inset-0 flex flex-col items-center justify-center animate-pulse">
                  <Server size={48} className="text-[#d4af37]" />
               </div>
            </div>
            <div className="text-[#d4af37] font-black tracking-[0.5em] text-xl mb-4 text-center">
              {connectionStage === 1 && "寻迹宗门网关..."}
              {connectionStage === 2 && "同步秘库名册..."}
              {connectionStage === 3 && "校准三维链路..."}
            </div>
          </div>
        )}

        <div className="w-full max-w-xl bg-[#161618] border border-[#d4af37]/20 p-12 rounded-lg shadow-[0_0_100px_rgba(212,175,55,0.05)] space-y-8 relative z-10">
          <CornerDecor className="top-0 left-0" />
          <CornerDecor className="bottom-0 right-0 rotate-180" />
          
          <div className="text-center space-y-4">
            <div className="inline-flex bg-gradient-to-b from-[#d4af37] to-[#8a6d1e] p-5 rounded-full mb-2 shadow-xl shadow-black/50">
              <Sword className="text-[#0c0c0e]" size={42} />
            </div>
            <h1 className="text-4xl font-black tracking-[0.3em] text-[#d4af37] drop-shadow-sm uppercase">星云阁<span className="text-white/80">·网关管理</span></h1>
            <p className="text-[#d4af37]/40 text-[10px] tracking-[0.5em] font-bold uppercase">Multidimensional Gateway & Character DB Control</p>
          </div>

          <form onSubmit={handleConnect} className="grid grid-cols-2 gap-6">
            <div className="col-span-1 space-y-1">
              <label className="text-[10px] font-bold text-[#d4af37]/60 uppercase tracking-widest">宗门节点 (IP/Host)</label>
              <input required type="text" value={dbConfig.host} onChange={e => setDbConfig({...dbConfig, host: e.target.value})} className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-3 text-[#d4af37] focus:border-[#d4af37] outline-none" />
            </div>
            <div className="col-span-1 space-y-1">
              <label className="text-[10px] font-bold text-[#d4af37]/60 uppercase tracking-widest">秘库名称 (Database)</label>
              <input required type="text" value={dbConfig.name} onChange={e => setDbConfig({...dbConfig, name: e.target.value})} className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-3 text-[#d4af37] focus:border-[#d4af37] outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-[#d4af37]/60 uppercase tracking-widest">执事之名 (User)</label>
              <input required type="text" value={dbConfig.user} onChange={e => setDbConfig({...dbConfig, user: e.target.value})} className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-3 text-[#d4af37] outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-[#d4af37]/60 uppercase tracking-widest">通关密语 (Pass)</label>
              <input required type="password" value={dbConfig.pass} onChange={e => setDbConfig({...dbConfig, pass: e.target.value})} className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-3 text-[#d4af37] outline-none" />
            </div>
            
            <div className="col-span-2 grid grid-cols-3 gap-4 border-t border-[#d4af37]/10 pt-6 mt-2">
               <div className="space-y-1">
                 <label className="text-[9px] font-bold text-[#d4af37]/40 uppercase tracking-widest text-center block">Gdeliveryd</label>
                 <input type="text" value={dbConfig.gdeliveryd} onChange={e => setDbConfig({...dbConfig, gdeliveryd: e.target.value})} className="w-full bg-black/40 border-[#d4af37]/10 border rounded p-2 text-center text-xs text-[#d4af37]/80" />
               </div>
               <div className="space-y-1">
                 <label className="text-[9px] font-bold text-[#d4af37]/40 uppercase tracking-widest text-center block">Ganedbd</label>
                 <input type="text" value={dbConfig.ganedbd} onChange={e => setDbConfig({...dbConfig, ganedbd: e.target.value})} className="w-full bg-black/40 border-[#d4af37]/10 border rounded p-2 text-center text-xs text-[#d4af37]/80" />
               </div>
               <div className="space-y-1">
                 <label className="text-[9px] font-bold text-[#d4af37]/40 uppercase tracking-widest text-center block">UniqueNamed</label>
                 <input type="text" value={dbConfig.uniquenamed} onChange={e => setDbConfig({...dbConfig, uniquenamed: e.target.value})} className="w-full bg-black/40 border-[#d4af37]/10 border rounded p-2 text-center text-xs text-[#d4af37]/80" />
               </div>
            </div>

            <button type="submit" className="col-span-2 bg-gradient-to-r from-[#8a6d1e] via-[#d4af37] to-[#8a6d1e] text-[#0c0c0e] font-black py-4 rounded-sm transition-all shadow-xl active:scale-[0.98] uppercase tracking-[0.4em] mt-4">
              <Zap size={18} className="inline mr-2 mb-1" /> 开启宗门链通
            </button>
          </form>
        </div>
      </div>
    );
  }

  const toggleSelectAll = () => {
    if (selectedAccountIds.length === accounts.length) {
      setSelectedAccountIds([]);
    } else {
      setSelectedAccountIds(accounts.map(a => a.id));
    }
  };

  const toggleSelect = (id: number) => {
    setSelectedAccountIds(prev => prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]);
  };

  return (
    <div className="min-h-screen bg-[#0c0c0e] text-[#d4af37]/80 flex overflow-hidden font-serif selection:bg-[#d4af37]/30 selection:text-white">
      <CloudPattern />
      
      <aside className="w-72 border-r border-[#d4af37]/10 flex flex-col p-8 bg-[#0c0c0e]/80 backdrop-blur-xl shrink-0 relative z-20">
        <div className="flex items-center space-x-4 mb-14 px-2">
          <div className="bg-gradient-to-br from-[#d4af37] to-[#8a6d1e] p-2.5 rounded shadow-[0_0_15px_rgba(212,175,55,0.3)]">
            <Flame className="text-[#0c0c0e]" size={28} />
          </div>
          <span className="text-2xl font-black tracking-[0.2em] text-[#d4af37] uppercase italic">星云阁<span className="text-white/60 ml-1">GM</span></span>
        </div>
        
        <nav className="flex-1 space-y-4">
          <SidebarItem icon={Activity} label="乾坤概览" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <SidebarItem icon={Users} label="弟子名册" active={activeTab === 'accounts'} onClick={() => setActiveTab('accounts')} />
          <SidebarItem icon={Megaphone} label="江湖令榜" active={activeTab === 'announcements'} onClick={() => setActiveTab('announcements')} />
        </nav>

        <div className="mt-auto space-y-4">
           <div className="p-4 bg-black/40 border border-[#d4af37]/10 rounded-sm space-y-3">
              <div className="flex items-center gap-2 text-[9px] font-black text-[#d4af37]/40 uppercase tracking-widest">
                 <Link size={10} /> 链通状态
              </div>
              <div className="grid grid-cols-2 gap-y-2 text-[9px] font-bold">
                <span className="opacity-40">网关 29100:</span>
                <span className="text-emerald-500 text-right font-black uppercase tracking-tighter">● Online</span>
                <span className="opacity-40">存储 29400:</span>
                <span className="text-emerald-500 text-right font-black uppercase tracking-tighter">● Online</span>
                <span className="opacity-40">命名 29401:</span>
                <span className="text-emerald-500 text-right font-black uppercase tracking-tighter">● Online</span>
              </div>
           </div>
          <button onClick={() => setIsLoggedIn(false)} className="group flex items-center space-x-3 text-[#d4af37]/40 hover:text-rose-500 transition-all px-4 py-2 w-full text-left font-black tracking-widest text-sm uppercase">
            <LogOut size={18} /> 隐退江湖
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto bg-[#0c0c0e] relative z-10 custom-scrollbar">
        <header className="sticky top-0 z-30 flex items-center justify-between px-12 py-6 bg-[#0c0c0e]/90 backdrop-blur-md border-b border-[#d4af37]/10">
          <div className="flex-1">
             {announcements.length > 0 && (
               <div className="flex items-center gap-4 text-[#d4af37] bg-[#d4af37]/5 px-6 py-3 rounded-sm border border-[#d4af37]/10 max-w-2xl overflow-hidden relative">
                  <Megaphone size={16} className="shrink-0 animate-bounce" />
                  <div className="text-xs font-bold tracking-widest italic truncate transition-all duration-500">
                    {announcements[activeAnnIndex].type === '定时' && <span className="text-rose-400 mr-2">[{announcements[activeAnnIndex].time}]</span>}
                    {announcements[activeAnnIndex].content}
                  </div>
                  <div className="ml-auto flex gap-1">
                    {announcements.map((_, i) => (
                      <div key={i} className={`w-1 h-1 rounded-full ${i === activeAnnIndex ? 'bg-[#d4af37]' : 'bg-[#d4af37]/20'}`} />
                    ))}
                  </div>
               </div>
             )}
          </div>
          <div className="flex items-center space-x-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#d4af37]/40" size={16} />
              <input type="text" placeholder="搜寻豪杰/弟子..." className="bg-black/40 border-[#d4af37]/20 border rounded-full pl-10 pr-6 py-2.5 text-sm text-[#d4af37] focus:outline-none focus:border-[#d4af37] w-72 transition-all placeholder:text-[#d4af37]/20 font-black tracking-widest" />
            </div>
            <button onClick={() => setEditModal({type: 'db_settings'})} className="p-2.5 bg-[#161618] border border-[#d4af37]/20 rounded-lg text-[#d4af37]/60 hover:text-[#d4af37] transition-all shadow-inner">
              <Settings size={22} />
            </button>
          </div>
        </header>

        <div className="p-12 max-w-7xl mx-auto space-y-12">
          
          {activeTab === 'dashboard' && (
            <div className="space-y-12 animate-in fade-in duration-700">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {[
                  { label: "链通灵压", value: "3,124", icon: Zap, color: "text-amber-500" },
                  { label: "元宝盈余", value: "158,400", icon: DollarSign, color: "text-[#d4af37]" },
                  { label: "江湖波动", value: "0.04%", icon: Activity, color: "text-indigo-400" },
                  { label: "名册密语", value: accounts.length + " 条", icon: BookOpen, color: "text-purple-400" },
                ].map((stat, i) => {
                  const IconComp = stat.icon;
                  return (
                    <div key={i} className="bg-[#161618] border border-[#d4af37]/10 p-8 rounded shadow-lg group hover:border-[#d4af37]/40 transition-all relative overflow-hidden">
                      <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-30 transition-opacity">
                        <IconComp size={48} />
                      </div>
                      <div className="flex justify-between items-start mb-6 font-black uppercase tracking-[0.2em] text-[10px] opacity-40">{stat.label}</div>
                      <div className="text-4xl font-black text-white tracking-tighter">{stat.value}</div>
                    </div>
                  );
                })}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                <div className="lg:col-span-2 bg-[#161618] border border-[#d4af37]/10 p-10 rounded shadow-xl min-h-[450px] relative overflow-hidden">
                  <h3 className="text-xl font-black text-white flex items-center gap-3 mb-10 tracking-[0.2em] relative z-10"><BarChart3 size={24} className="text-[#d4af37]" /> 江湖人烟图</h3>
                  <div className="h-[320px] w-full relative z-10">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={GROWTH_DATA}>
                        <defs><linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#d4af37" stopOpacity={0.2}/><stop offset="95%" stopColor="#d4af37" stopOpacity={0}/></linearGradient></defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#d4af3711" vertical={false} />
                        <XAxis dataKey="time" stroke="#d4af3744" fontSize={12} tickLine={false} axisLine={false} tick={{fill: '#d4af3788'}} />
                        <YAxis stroke="#d4af3744" fontSize={12} tickLine={false} axisLine={false} tick={{fill: '#d4af3788'}} />
                        <Tooltip contentStyle={{ backgroundColor: '#0c0c0e', border: '1px solid #d4af3744' }} labelStyle={{ color: '#d4af37' }} />
                        <Area type="monotone" dataKey="users" stroke="#d4af37" strokeWidth={3} fillOpacity={1} fill="url(#colorUsers)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                
                <div className="bg-[#161618] border border-[#d4af37]/10 p-10 rounded shadow-xl flex flex-col relative">
                  <CornerDecor className="top-0 right-0 rotate-90" />
                  <h3 className="text-xl font-black text-white mb-8 flex items-center gap-3 tracking-[0.2em]"><MessageSquare size={24} className="text-[#d4af37]" /> 百晓生传音</h3>
                  <div className="flex-1 overflow-y-auto space-y-4 mb-6 pr-4 custom-scrollbar h-[250px]">
                    {chat.map((msg, i) => (
                      <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[90%] px-4 py-3 rounded text-sm ${msg.role === 'user' ? 'bg-[#d4af37]/20 text-white' : 'bg-black/40 text-[#d4af37]/90 border-l-2 border-[#d4af37]/40'}`}>{msg.content}</div>
                      </div>
                    ))}
                  </div>
                  <div className="relative mt-4">
                    <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && askAi()} disabled={isAiLoading} placeholder="修书百晓生..." className="w-full bg-black/40 border-[#d4af37]/20 border rounded-sm pl-4 pr-12 py-4 text-sm text-[#d4af37] outline-none" />
                    <button onClick={askAi} disabled={isAiLoading || !input} className="absolute right-2 top-1/2 -translate-y-1/2 bg-[#d4af37] text-black p-2 rounded transition-all active:scale-90"><Zap size={16} /></button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'accounts' && (
            <div className="space-y-4 animate-in fade-in duration-700">
              {selectedAccountIds.length > 0 && (
                <div className="bg-[#d4af37] text-[#0c0c0e] px-8 py-4 rounded-sm flex items-center justify-between shadow-2xl animate-in slide-in-from-top-4">
                  <div className="flex items-center gap-4">
                     <CheckSquare size={20} />
                     <span className="font-black tracking-widest uppercase text-sm">已选中 {selectedAccountIds.length} 位弟子</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <button onClick={() => setEditModal({type: 'batch_recharge'})} className="px-4 py-2 bg-black/10 hover:bg-black/20 text-black font-black text-xs rounded border border-black/20 flex items-center gap-2 tracking-widest uppercase transition-all">
                       <DollarSign size={14} /> 批量充值
                    </button>
                    <button onClick={() => setEditModal({type: 'batch_ban'})} className="px-4 py-2 bg-black/10 hover:bg-black/20 text-black font-black text-xs rounded border border-black/20 flex items-center gap-2 tracking-widest uppercase transition-all">
                       <Ban size={14} /> 批量封禁
                    </button>
                    <button onClick={handleBatchDelete} className="px-4 py-2 bg-rose-600 text-white font-black text-xs rounded border border-rose-700 flex items-center gap-2 tracking-widest uppercase hover:bg-rose-700 shadow-lg transition-all">
                       <Trash2 size={14} /> 批量驱逐
                    </button>
                    <div className="w-px h-6 bg-black/20 mx-2" />
                    <button onClick={() => setSelectedAccountIds([])} className="p-2 hover:bg-black/10 rounded transition-all"><X size={20}/></button>
                  </div>
                </div>
              )}
              
              <div className="bg-[#161618] border border-[#d4af37]/10 rounded shadow-2xl overflow-hidden relative">
                <CornerDecor className="top-0 left-0" />
                <div className="p-10 border-b border-[#d4af37]/10 flex justify-between items-center bg-black/20">
                  <h3 className="text-2xl font-black text-white tracking-[0.2em]">诸徒名册</h3>
                  <button onClick={() => setEditModal({ type: 'add_account' })} className="bg-[#d4af37] text-black px-6 py-2.5 rounded-sm font-black text-sm flex items-center gap-2 hover:bg-[#b8952e] shadow-lg transition-all active:scale-95 tracking-widest uppercase"><UserPlus size={20} /> 收录新徒</button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-black/40 text-left">
                      <tr className="text-[#d4af37]/50 text-xs font-black uppercase tracking-[0.3em]">
                        <th className="px-10 py-5 w-16 text-center">
                           <button onClick={toggleSelectAll} className="p-1 hover:text-[#d4af37] transition-all inline-block align-middle">
                              {selectedAccountIds.length === accounts.length ? <CheckSquare size={18}/> : <Square size={18}/>}
                           </button>
                        </th>
                        <th className="px-10 py-5 font-black">名号</th>
                        <th className="px-10 py-5 font-black">身份标识</th>
                        <th className="px-10 py-5 font-black">元宝</th>
                        <th className="px-10 py-5 font-black">状态</th>
                        <th className="px-10 py-5 text-right font-black">掌门批示</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#d4af37]/5">
                      {accounts.map(acc => {
                        const userChars = characters.filter(c => c.userId === acc.id);
                        const isSelected = selectedAccountIds.includes(acc.id);
                        return (
                          <tr key={acc.id} className={`${isSelected ? 'bg-[#d4af37]/10' : 'hover:bg-[#d4af37]/5'} transition-colors group`}>
                            <td className="px-10 py-7 text-center">
                               <button onClick={() => toggleSelect(acc.id)} className={`p-1 transition-all inline-block align-middle ${isSelected ? 'text-[#d4af37]' : 'text-[#d4af37]/20 group-hover:text-[#d4af37]/40'}`}>
                                  {isSelected ? <CheckSquare size={18}/> : <Square size={18}/>}
                               </button>
                            </td>
                            <td className="px-10 py-7">
                              <div className="text-white font-bold text-lg tracking-wider group-hover:text-[#d4af37] transition-colors">{acc.username}</div>
                              <div className="text-[#d4af37]/30 text-[10px] mt-1 tracking-widest uppercase font-black">ID: {acc.id}</div>
                            </td>
                            <td className="px-10 py-7">
                              <div className="flex flex-wrap gap-2">
                                {acc.isGM && <TraditionalBadge color="purple"><ShieldAlert size={10} className="text-[#d4af37]" /> 戒律使</TraditionalBadge>}
                                {acc.vip > 0 && <TraditionalBadge color="gold"><Crown size={10} className="text-[#d4af37]" /> 位阶 {acc.vip}</TraditionalBadge>}
                                {userChars.length > 0 && <TraditionalBadge color="jade"><Gamepad2 size={10} /> {userChars.length} 豪杰</TraditionalBadge>}
                              </div>
                            </td>
                            <td className="px-10 py-7 font-black text-[#d4af37] tracking-wider text-lg">{acc.points.toLocaleString()}</td>
                            <td className="px-10 py-7">
                              <span className={`px-2 py-1 rounded-sm text-[10px] font-black border tracking-widest uppercase ${acc.status === '正常' ? 'bg-[#00a86b]/10 text-[#00a86b] border-[#00a86b]/20' : 'bg-[#e34234]/10 text-[#e34234] border-[#e34234]/20'}`}>{acc.status}</span>
                            </td>
                            <td className="px-10 py-7 text-right">
                              <div className="flex justify-end gap-3 opacity-30 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => setEditModal({type: 'char_details', target: acc})} className="p-2.5 bg-black/40 text-[#2ecc71] rounded hover:bg-[#2ecc71] hover:text-white transition-all shadow-inner" title="豪杰详情"><Eye size={16} /></button>
                                <button onClick={() => setEditModal({type: 'recharge', target: acc})} className="p-2.5 bg-black/40 text-[#00a86b] rounded hover:bg-[#00a86b] hover:text-white transition-all shadow-inner" title="注入元宝"><DollarSign size={16} /></button>
                                <button onClick={() => setEditModal({type: 'password', target: acc})} className="p-2.5 bg-black/40 text-[#d4af37] rounded hover:bg-[#d4af37] hover:text-black transition-all shadow-inner" title="重设密语"><Key size={16} /></button>
                                <button onClick={() => handleDeleteAccount(acc.id)} className="p-2.5 bg-black/40 text-[#e34234] rounded hover:bg-[#e34234] hover:text-white transition-all shadow-inner" title="驱逐出山"><Trash2 size={16} /></button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'announcements' && (
            <div className="bg-[#161618] border border-[#d4af37]/10 p-12 rounded shadow-2xl relative overflow-hidden animate-in fade-in duration-700">
              <div className="flex justify-between items-center mb-12 relative z-10">
                <h3 className="text-3xl font-black text-white tracking-[0.2em] flex items-center gap-4"><Megaphone className="text-[#d4af37]" size={32} /> 百晓通告榜</h3>
                <button onClick={() => setEditModal({ type: 'add_announcement' })} className="bg-[#d4af37] text-black px-8 py-3 rounded-sm font-black flex items-center gap-3 hover:bg-[#b8952e] shadow-xl transition-all active:scale-95 tracking-widest uppercase"><Plus size={22} /> 发布江湖令</button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
                {announcements.map(ann => (
                  <div key={ann.id} className="bg-black/30 border-l-4 border-[#d4af37] p-8 rounded-sm flex items-center gap-6 group hover:bg-black/40 transition-all">
                    <div className="p-4 rounded-full bg-[#d4af37]/10 text-[#d4af37]">
                      {ann.type === '即时' ? <Zap size={24} /> : <Clock size={24} />}
                    </div>
                    <div className="flex-1">
                       <div className="flex items-center gap-2 mb-1">
                          <TraditionalBadge color={ann.type === '即时' ? 'gold' : 'vermillion'}>{ann.type}</TraditionalBadge>
                          {ann.type === '定时' && <span className="text-[10px] font-black text-rose-500 uppercase tracking-widest">{ann.time} 执行</span>}
                       </div>
                       <p className="text-[#d4af37]/80 italic text-sm leading-relaxed">“ {ann.content} ”</p>
                    </div>
                    <button onClick={() => handleDeleteAnnouncement(ann.id)} className="opacity-0 group-hover:opacity-100 p-3 text-[#e34234] transition-all hover:scale-110"><Trash2 size={20} /></button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      <Modal 
        isOpen={!!editModal} 
        onClose={() => setEditModal(null)} 
        title={
          editModal?.type === 'char_details' ? `[${editModal.target.username}] 的豪侠志` :
          editModal?.type === 'edit_inventory' ? `管理宝库: ${editModal.target.name}` :
          editModal?.type === 'add_account' ? '弟子招募令' :
          editModal?.type === 'db_settings' ? '网关链路全局配置' :
          editModal?.type === 'recharge' ? '注入修为(充值)' : 
          editModal?.type === 'password' ? '重设通关密语' :
          editModal?.type === 'batch_recharge' ? '批量注入修为' :
          editModal?.type === 'batch_ban' ? '批量执行诫命' : '发布江湖令'
        }
      >
        {editModal && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
            {editModal.type === 'char_details' && (
              <div className="space-y-8">
                 <div className="flex justify-between items-center bg-black/40 p-6 border border-[#d4af37]/10 rounded-sm">
                   <div className="flex items-center gap-4">
                      <div className="p-3 rounded-full bg-[#d4af37]/10 text-[#d4af37] shadow-inner">
                        <Users2 size={24} />
                      </div>
                      <div>
                        <div className="text-white font-black tracking-widest text-lg uppercase">下属豪杰名录</div>
                        <div className="text-[10px] text-[#d4af37]/40 font-bold uppercase tracking-widest">Managing Characters under {editModal.target.username}</div>
                      </div>
                   </div>
                 </div>
                 
                 <div className="space-y-6">
                    {characters.filter(c => c.userId === editModal.target.id).map(char => {
                      const isEditing = editingCharId === char.id;
                      return (
                        <div key={char.id} className={`bg-black/20 border ${isEditing ? 'border-[#d4af37]/60 ring-1 ring-[#d4af37]/20' : 'border-[#d4af37]/5'} p-8 rounded-sm relative group transition-all`}>
                          <div className="grid grid-cols-2 gap-10">
                             <div className="space-y-6">
                                {isEditing ? (
                                  <div className="space-y-4 animate-in fade-in zoom-in-95 duration-200">
                                     <div className="space-y-1">
                                        <label className="text-[9px] font-black text-[#d4af37]/40 uppercase tracking-widest">豪杰名号</label>
                                        <input 
                                          autoFocus
                                          defaultValue={char.name} 
                                          id={`name-${char.id}`}
                                          className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-2 text-[#d4af37] font-black outline-none focus:border-[#d4af37]" 
                                        />
                                     </div>
                                     <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-1">
                                          <label className="text-[9px] font-black text-[#d4af37]/40 uppercase tracking-widest">修为等级</label>
                                          <input 
                                            type="number" 
                                            defaultValue={char.level} 
                                            id={`level-${char.id}`}
                                            className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-2 text-[#d4af37] font-black outline-none focus:border-[#d4af37]" 
                                          />
                                        </div>
                                        <div className="space-y-1">
                                          <label className="text-[9px] font-black text-[#d4af37]/40 uppercase tracking-widest">豪杰职业</label>
                                          <select 
                                            id={`roles-${char.id}`}
                                            defaultValue={char.roles} 
                                            className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-2 text-[#d4af37] font-black outline-none focus:border-[#d4af37]"
                                          >
                                            {JOBS.map(j => <option key={j} value={j}>{j}</option>)}
                                          </select>
                                        </div>
                                     </div>
                                     <div className="flex gap-2 pt-2">
                                        <button 
                                          onClick={() => {
                                            const nameInput = document.getElementById(`name-${char.id}`) as HTMLInputElement;
                                            const levelInput = document.getElementById(`level-${char.id}`) as HTMLInputElement;
                                            const rolesInput = document.getElementById(`roles-${char.id}`) as HTMLSelectElement;
                                            handleUpdateCharacter(char.id, { 
                                              name: nameInput.value, 
                                              level: Number(levelInput.value), 
                                              roles: rolesInput.value as JobType 
                                            });
                                          }}
                                          className="flex-1 bg-[#d4af37] text-black py-2 rounded text-[10px] font-black uppercase tracking-widest shadow-lg transition-all"
                                        >
                                          保存归卷
                                        </button>
                                        <button onClick={() => setEditingCharId(null)} className="flex-1 bg-black/40 text-[#d4af37]/60 py-2 rounded text-[10px] font-black uppercase tracking-widest border border-[#d4af37]/10 transition-all">取消</button>
                                     </div>
                                  </div>
                                ) : (
                                  <>
                                    <div className="flex items-center gap-4">
                                      <span className="text-3xl font-black text-white tracking-widest">{char.name}</span>
                                      <TraditionalBadge color="jade">{char.roles}</TraditionalBadge>
                                    </div>
                                    <div className="grid grid-cols-2 gap-4 text-[10px] font-black uppercase tracking-widest">
                                       <div>
                                          <div className="opacity-40 mb-1 font-bold">修为等级</div>
                                          <div className="text-[#d4af37] text-xl font-black">Lv. {char.level}</div>
                                       </div>
                                       <div>
                                          <div className="opacity-40 mb-1 font-bold">武林威望 (PVP)</div>
                                          <div className="text-white text-xl font-black">{char.pvp}</div>
                                       </div>
                                    </div>
                                    <div className="space-y-2">
                                       <div className="text-[9px] opacity-40 font-black uppercase tracking-widest flex items-center gap-2"><Sparkles size={12}/> 掌握绝学</div>
                                       <div className="flex flex-wrap gap-2">
                                          {char.skills.map((s,i) => <TraditionalBadge key={i} color="purple">{s}</TraditionalBadge>)}
                                       </div>
                                    </div>
                                  </>
                                )}
                             </div>
                             <div className="space-y-6 border-l border-[#d4af37]/10 pl-10">
                                <div className="text-[10px] opacity-40 font-black uppercase tracking-widest flex items-center gap-2 font-bold"><Package size={14}/> 库藏状态 (Inventory & Warehouse)</div>
                                <div className="grid grid-cols-2 gap-4">
                                  <button onClick={() => setEditModal({type: 'edit_inventory', target: char})} className="bg-[#d4af37]/5 border border-[#d4af37]/10 p-4 rounded-sm text-center hover:bg-[#d4af37]/10 transition-all group/btn shadow-inner">
                                     <div className="text-[#d4af37] font-black text-xl mb-1 group-hover/btn:scale-110 transition-transform">{char.inventory.length}</div>
                                     <div className="text-[9px] opacity-40 font-black tracking-widest uppercase">随身囊</div>
                                  </button>
                                  <button onClick={() => setEditModal({type: 'edit_inventory', target: char})} className="bg-[#d4af37]/5 border border-[#d4af37]/10 p-4 rounded-sm text-center hover:bg-[#d4af37]/10 transition-all group/btn shadow-inner">
                                     <div className="text-[#d4af37] font-black text-xl mb-1 group-hover/btn:scale-110 transition-transform">{char.warehouse.length}</div>
                                     <div className="text-[9px] opacity-40 font-black tracking-widest uppercase">私人金库</div>
                                  </button>
                                </div>
                                <div className="pt-2 flex gap-4">
                                  {!isEditing && (
                                    <button onClick={() => setEditingCharId(char.id)} className="flex-1 bg-[#d4af37]/5 border border-[#d4af37]/20 text-[#d4af37] py-3 rounded text-[10px] font-black uppercase tracking-widest hover:bg-[#d4af37] hover:text-black transition-all flex items-center justify-center gap-2 shadow-lg">
                                       <Edit3 size={14}/> 修正传记
                                    </button>
                                  )}
                                  <button onClick={() => handleDeleteCharacter(char.id)} className="p-3 text-[#e34234] hover:bg-rose-600 hover:text-white transition-all rounded shadow-inner border border-transparent hover:border-rose-700">
                                    <Trash2 size={18}/>
                                  </button>
                                </div>
                             </div>
                          </div>
                        </div>
                      );
                    })}
                    {characters.filter(c => c.userId === editModal.target.id).length === 0 && (
                      <div className="py-20 text-center opacity-20 italic bg-black/10 border border-dashed border-[#d4af37]/10 rounded font-black tracking-widest uppercase">此弟子尚未在江湖中开辟豪侠角色</div>
                    )}
                 </div>
              </div>
            )}

            {editModal.type === 'password' && (
              <form onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                const pass = fd.get('newPass') as string;
                const confirmPass = fd.get('confirmPass') as string;
                if (pass !== confirmPass) {
                  alert("两次输入不一致！");
                  return;
                }
                handleUpdatePassword(editModal.target.id, pass);
              }} className="space-y-6">
                 <div className="text-center space-y-2 mb-8">
                    <div className="text-[#d4af37]/40 text-[10px] font-black uppercase tracking-widest font-bold">弟子名号</div>
                    <div className="text-2xl font-black text-white tracking-[0.2em] uppercase">{editModal.target.username}</div>
                 </div>
                 <div className="space-y-4">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-[#d4af37]/60 uppercase tracking-widest font-bold">新设通关密语 (New Password)</label>
                       <div className="relative">
                          <Key size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#d4af37]/40" />
                          <input required name="newPass" type="password" placeholder="请输入新密语..." className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-4 pl-12 text-[#d4af37] focus:border-[#d4af37] outline-none font-black" />
                       </div>
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-[#d4af37]/60 uppercase tracking-widest font-bold">确认新密语 (Confirm Password)</label>
                       <input required name="confirmPass" type="password" placeholder="请再次确认..." className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-4 text-[#d4af37] focus:border-[#d4af37] outline-none font-black" />
                    </div>
                 </div>
                 <div className="bg-[#d4af37]/5 border border-[#d4af37]/10 p-4 rounded text-[#d4af37]/60 text-[10px] font-bold text-center italic">
                   “ 密语一旦修正，旧有印记将悉数作废。 ”
                 </div>
                 <button type="submit" className="w-full bg-[#d4af37] text-[#0c0c0e] py-5 rounded-sm font-black uppercase tracking-widest shadow-xl hover:bg-[#b8952e] transition-all">确认重设密语</button>
              </form>
            )}

            {editModal.type === 'batch_recharge' && (
              <form onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                handleBatchRecharge(Number(fd.get('amount')));
              }} className="space-y-6">
                 <div className="text-center mb-4">
                    <div className="text-[#d4af37]/40 text-[10px] font-black uppercase tracking-widest mb-1 font-bold">批量注入灵石</div>
                    <div className="text-3xl font-black text-white tracking-widest uppercase">灵气普降 {selectedAccountIds.length} 位弟子</div>
                 </div>
                 <input required name="amount" type="number" placeholder="输入充值数值..." className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-6 text-[#d4af37] text-4xl font-black text-center focus:border-[#d4af37] outline-none" />
                 <button type="submit" className="w-full bg-[#00a86b] text-white py-5 rounded-sm font-black uppercase tracking-widest shadow-xl hover:bg-emerald-700 transition-all">确认批量赏赐</button>
              </form>
            )}

            {editModal.type === 'batch_ban' && (
              <div className="space-y-8 text-center py-6">
                 <div className="space-y-2">
                    <div className="text-[#d4af37]/40 text-[10px] font-black uppercase tracking-widest font-bold">诫命执行</div>
                    <div className="text-2xl font-black text-white tracking-widest uppercase">对 {selectedAccountIds.length} 位弟子施加因果</div>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <button onClick={() => handleBatchBan('正常')} className="bg-emerald-600/20 border border-emerald-600 text-emerald-500 py-6 rounded-sm font-black uppercase tracking-widest hover:bg-emerald-600 hover:text-white transition-all flex flex-col items-center gap-2">
                       <CheckCircle2 size={32} /> 解除禁锢
                    </button>
                    <button onClick={() => handleBatchBan('封禁')} className="bg-rose-600/20 border border-rose-600 text-rose-500 py-6 rounded-sm font-black uppercase tracking-widest hover:bg-rose-600 hover:text-white transition-all flex flex-col items-center gap-2">
                       <Ban size={32} /> 封禁修为
                    </button>
                 </div>
              </div>
            )}

            {editModal.type === 'db_settings' && (
              <form onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                setDbConfig({
                  ...dbConfig,
                  host: fd.get('host') as string,
                  port: fd.get('port') as string,
                  name: fd.get('name') as string,
                  user: fd.get('user') as string,
                  pass: fd.get('pass') as string,
                  gdeliveryd: fd.get('gdeliveryd') as string,
                  ganedbd: fd.get('ganedbd') as string,
                  uniquenamed: fd.get('uniquenamed') as string,
                });
                setEditModal(null);
                alert("全局配置已更新。");
              }} className="space-y-6">
                 <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-1">
                      <label className="text-[10px] font-bold text-[#d4af37]/60 uppercase tracking-widest font-bold">宗门节点 (IP)</label>
                      <input name="host" defaultValue={dbConfig.host} className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-3 text-[#d4af37] font-black outline-none" />
                   </div>
                   <div className="space-y-1">
                      <label className="text-[10px] font-bold text-[#d4af37]/60 uppercase tracking-widest font-bold">秘库名称 (Database)</label>
                      <input name="name" defaultValue={dbConfig.name} className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-3 text-[#d4af37] font-black outline-none" />
                   </div>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-[#d4af37]/60 uppercase tracking-widest font-bold">执事之名 (User)</label>
                      <input name="user" defaultValue={dbConfig.user} className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-3 text-[#d4af37] font-black outline-none" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-[#d4af37]/60 uppercase tracking-widest font-bold">通关密语 (Pass)</label>
                      <input name="pass" type="password" defaultValue={dbConfig.pass} className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-3 text-[#d4af37] font-black outline-none" />
                    </div>
                 </div>
                 <div className="grid grid-cols-3 gap-4 border-t border-[#d4af37]/10 pt-6">
                    <div className="space-y-1 text-center">
                       <label className="text-[9px] font-bold text-[#d4af37]/40 uppercase tracking-widest font-bold">Gdeliveryd</label>
                       <input name="gdeliveryd" defaultValue={dbConfig.gdeliveryd} className="w-full bg-black/40 border-[#d4af37]/10 border rounded p-3 text-center text-[#d4af37] font-black outline-none" />
                    </div>
                    <div className="space-y-1 text-center">
                       <label className="text-[9px] font-bold text-[#d4af37]/40 uppercase tracking-widest font-bold">Ganedbd</label>
                       <input name="ganedbd" defaultValue={dbConfig.ganedbd} className="w-full bg-black/40 border-[#d4af37]/10 border rounded p-3 text-center text-[#d4af37] font-black outline-none" />
                    </div>
                    <div className="space-y-1 text-center">
                       <label className="text-[9px] font-bold text-[#d4af37]/40 uppercase tracking-widest font-bold">UniqueNamed</label>
                       <input name="uniquenamed" defaultValue={dbConfig.uniquenamed} className="w-full bg-black/40 border-[#d4af37]/10 border rounded p-3 text-center text-[#d4af37] font-black outline-none" />
                    </div>
                 </div>
                 <button type="submit" className="w-full bg-[#d4af37] text-black py-4 rounded-sm font-black uppercase tracking-widest shadow-xl hover:bg-[#b8952e] transition-all">保存宗门链路配置</button>
              </form>
            )}

            {editModal.type === 'recharge' && (
              <form onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                handleUpdateAccount(editModal.target.id, { points: editModal.target.points + Number(fd.get('amount')) });
              }} className="space-y-6">
                 <div className="text-center mb-4">
                    <div className="text-[#d4af37]/40 text-[10px] font-bold uppercase tracking-widest mb-1 font-bold">当前元宝盈余</div>
                    <div className="text-4xl font-black text-white tracking-widest">{editModal.target.points.toLocaleString()}</div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-[#d4af37]/60 uppercase tracking-widest font-bold">注入数值 (Amount)</label>
                    <input required name="amount" type="number" placeholder="输入赏赐数值..." className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-6 text-[#d4af37] text-3xl font-black text-center focus:border-[#d4af37] outline-none" />
                 </div>
                 <button type="submit" className="w-full bg-emerald-600 text-white py-5 rounded-sm font-black uppercase tracking-widest shadow-xl transition-all hover:bg-emerald-700">确认注入修为</button>
              </form>
            )}

            {editModal.type === 'add_account' && (
              <form onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                handleAddAccount(Object.fromEntries(fd.entries()));
              }} className="space-y-6">
                <input required name="username" placeholder="弟子名号" className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-4 text-[#d4af37] font-black uppercase tracking-widest outline-none" />
                <input required name="password" type="password" placeholder="通关密语" className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-4 text-[#d4af37] outline-none" />
                <div className="grid grid-cols-2 gap-4">
                  <input name="points" type="number" defaultValue="1000" placeholder="初始元宝" className="bg-black/40 border-[#d4af37]/20 border rounded p-4 text-[#d4af37] font-black" />
                  <input name="vip" type="number" defaultValue="0" placeholder="VIP等级" className="bg-black/40 border-[#d4af37]/20 border rounded p-4 text-[#d4af37] font-black" />
                </div>
                <div className="flex items-center gap-3 bg-black/20 p-4 border border-[#d4af37]/10 rounded">
                   <input type="checkbox" name="isGM" id="isGM_check" className="w-4 h-4 accent-[#d4af37]" />
                   <label htmlFor="isGM_check" className="text-xs font-black text-[#d4af37]/60 uppercase tracking-widest cursor-pointer">授予戒律使(GM)特权</label>
                </div>
                <button type="submit" className="w-full bg-[#d4af37] text-black py-4 rounded-sm font-black uppercase tracking-widest shadow-xl hover:bg-[#b8952e] transition-all">正式收录</button>
              </form>
            )}

            {editModal.type === 'add_announcement' && (
              <form onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                handleAddAnnouncement(Object.fromEntries(fd.entries()));
              }} className="space-y-6">
                 <textarea required name="content" rows={4} className="w-full bg-black/40 border-[#d4af37]/20 border rounded p-4 text-[#d4af37] italic outline-none resize-none" placeholder="写下欲告知江湖之事..." />
                 <div className="grid grid-cols-2 gap-4">
                    <select name="type" className="bg-black text-[#d4af37] p-3 rounded border border-[#d4af37]/20 font-black outline-none">
                       <option value="即时">即时发布</option>
                       <option value="定时">定时发布</option>
                    </select>
                    <input name="time" type="time" className="bg-black text-[#d4af37] p-3 rounded border border-[#d4af37]/20 outline-none" />
                 </div>
                 <button type="submit" className="w-full bg-[#d4af37] text-black py-4 rounded-sm font-black uppercase tracking-widest hover:bg-[#b8952e] transition-all">颁布江湖令</button>
              </form>
            )}
          </div>
        )}
      </Modal>

      <style dangerouslySetInnerHTML={{ __html: `
        @import url('https://fonts.googleapis.com/css2?family=Noto+Serif+SC:wght@400;700;900&display=swap');
        body { font-family: 'Noto Serif SC', serif; }
        .custom-scrollbar::-webkit-scrollbar { width: 5px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: rgba(0,0,0,0.3); }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(212, 175, 55, 0.2); border-radius: 10px; }
        .truncate { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        input[type="number"]::-webkit-inner-spin-button, input[type="number"]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        select { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23d4af37' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 1rem center; }
      `}} />
    </div>
  );
};

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = createRoot(rootElement);
  root.render(<App />);
}
